import mapboxgl from 'mapbox-gl';
import { MAPBOX_ACCESS_TOKEN, DEFAULT_MAP_CENTER } from './constants';
import type { ResourceWithDetails } from '@shared/schema';

// Initialize mapbox with token
mapboxgl.accessToken = MAPBOX_ACCESS_TOKEN;

interface MapOptions {
  container: string;
  center?: [number, number];
  zoom?: number;
}

interface CreateMarkerOptions {
  resource: ResourceWithDetails;
  onClick?: (resource: ResourceWithDetails) => void;
}

export class MapService {
  map: mapboxgl.Map | null = null;
  markers: mapboxgl.Marker[] = [];
  userLocationMarker: mapboxgl.Marker | null = null;
  
  constructor() {}
  
  // Initialize the map
  init(options: MapOptions): mapboxgl.Map {
    if (this.map) return this.map;
    
    this.map = new mapboxgl.Map({
      container: options.container,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: options.center || [DEFAULT_MAP_CENTER.lng, DEFAULT_MAP_CENTER.lat],
      zoom: options.zoom || DEFAULT_MAP_CENTER.zoom,
    });
    
    // Add navigation controls (zoom in/out)
    this.map.addControl(new mapboxgl.NavigationControl(), 'top-right');
    
    return this.map;
  }
  
  // Create a marker for a resource
  createMarker(options: CreateMarkerOptions): mapboxgl.Marker {
    if (!this.map) throw new Error('Map not initialized');
    
    const { resource, onClick } = options;
    const { category } = resource;
    
    // Create custom marker element
    const el = document.createElement('div');
    el.className = 'resource-marker';
    el.innerHTML = `<i class="ri-${category.icon} text-lg"></i>`;
    el.style.backgroundColor = this.getCategoryColor(category.color);
    el.style.color = 'white';
    el.style.width = '32px';
    el.style.height = '32px';
    el.style.borderRadius = '50%';
    el.style.display = 'flex';
    el.style.justifyContent = 'center';
    el.style.alignItems = 'center';
    el.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';
    el.style.cursor = 'pointer';
    
    // Create and add the marker
    const marker = new mapboxgl.Marker(el)
      .setLngLat([resource.longitude, resource.latitude])
      .addTo(this.map);
    
    // Add click event if provided
    if (onClick) {
      el.addEventListener('click', () => onClick(resource));
    }
    
    this.markers.push(marker);
    return marker;
  }
  
  // Create markers for multiple resources
  createMarkers(resources: ResourceWithDetails[], onClick?: (resource: ResourceWithDetails) => void): void {
    this.clearMarkers();
    
    resources.forEach(resource => {
      this.createMarker({ resource, onClick });
    });
  }
  
  // Clear all resource markers
  clearMarkers(): void {
    this.markers.forEach(marker => marker.remove());
    this.markers = [];
  }
  
  // Add user's current location marker
  addUserLocationMarker(coords: { lat: number; lng: number }): void {
    if (!this.map) throw new Error('Map not initialized');
    
    // Remove existing user marker if any
    if (this.userLocationMarker) {
      this.userLocationMarker.remove();
    }
    
    // Create custom marker element
    const el = document.createElement('div');
    el.className = 'user-location-marker';
    el.innerHTML = `<i class="ri-map-pin-user-line text-lg"></i>`;
    el.style.backgroundColor = '#3b82f6';
    el.style.color = 'white';
    el.style.width = '36px';
    el.style.height = '36px';
    el.style.borderRadius = '50%';
    el.style.display = 'flex';
    el.style.justifyContent = 'center';
    el.style.alignItems = 'center';
    el.style.boxShadow = '0 2px 10px rgba(59, 130, 246, 0.5)';
    
    // Create and add the marker
    this.userLocationMarker = new mapboxgl.Marker(el)
      .setLngLat([coords.lng, coords.lat])
      .addTo(this.map);
    
    // Center map on user location
    this.map.flyTo({
      center: [coords.lng, coords.lat],
      zoom: 13,
      essential: true
    });
  }
  
  // Get user's current location
  getUserLocation(): Promise<{ lat: number; lng: number }> {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by your browser'));
        return;
      }
      
      navigator.geolocation.getCurrentPosition(
        position => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        error => {
          reject(error);
        },
        { enableHighAccuracy: true }
      );
    });
  }
  
  // Fly to specific coordinates
  flyTo(coords: { lat: number; lng: number }, zoom?: number): void {
    if (!this.map) throw new Error('Map not initialized');
    
    this.map.flyTo({
      center: [coords.lng, coords.lat],
      zoom: zoom || 15,
      essential: true
    });
  }
  
  // Fit bounds to include all markers
  fitBounds(): void {
    if (!this.map || this.markers.length === 0) return;
    
    const bounds = new mapboxgl.LngLatBounds();
    
    this.markers.forEach(marker => {
      bounds.extend(marker.getLngLat());
    });
    
    // Add user location to bounds if available
    if (this.userLocationMarker) {
      bounds.extend(this.userLocationMarker.getLngLat());
    }
    
    this.map.fitBounds(bounds, {
      padding: 50,
      maxZoom: 15
    });
  }
  
  // Get category color
  private getCategoryColor(color: string): string {
    const colorMap: Record<string, string> = {
      'green': '#10B981', // success
      'blue': '#3B82F6', // info
      'purple': '#8B5CF6', // purple
      'gray': '#6B7280', // gray
      'cyan': '#06B6D4', // cyan
      'red': '#EF4444', // error
    };
    
    return colorMap[color] || '#4F7942'; // Default to primary color
  }
}

// Create a singleton instance
const mapService = new MapService();

export default mapService;
