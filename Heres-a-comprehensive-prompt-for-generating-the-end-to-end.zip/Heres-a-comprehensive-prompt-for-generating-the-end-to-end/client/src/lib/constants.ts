// API endpoints
export const API_ENDPOINTS = {
  REGISTER: "/api/register",
  LOGIN: "/api/login",
  LOGOUT: "/api/logout",
  USER: "/api/user",
  RESOURCES: "/api/resources",
  CATEGORIES: "/api/categories",
  CHAT: "/api/chat",
  INIT_DEMO: "/api/init-demo-data",
};

// MapBox
export const MAPBOX_ACCESS_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN || "pk.eyJ1IjoiY29tbXVuaXR5YXBwIiwiYSI6ImNsZjUwbnBjMzE4cXEzcm1udGdtNDRkOWEifQ.w1UEO6XteZFqZe7jZP0N8A";

// Resource categories with their respective icons and colors
export const CATEGORY_ICONS: Record<string, { icon: string; color: string }> = {
  "Food Banks": {
    icon: "restaurant",
    color: "green",
  },
  "Shelters": {
    icon: "home-heart",
    color: "blue",
  },
  "Healthcare Clinics": {
    icon: "hospital",
    color: "purple",
  },
  "Government Services": {
    icon: "government",
    color: "gray",
  },
  "Employment Resources": {
    icon: "briefcase-4",
    color: "cyan",
  },
  "Mental Health Services": {
    icon: "mental-health",
    color: "red",
  },
};

// Default map center (Boulder, CO)
export const DEFAULT_MAP_CENTER = {
  lat: 40.0150,
  lng: -105.2705,
  zoom: 12,
};

// Distance options for filtering
export const DISTANCE_OPTIONS = [
  { value: 5, label: "5 miles" },
  { value: 10, label: "10 miles" },
  { value: 20, label: "20 miles" },
  { value: 50, label: "50 miles" },
];

// Initial chatbot message
export const INITIAL_CHATBOT_MESSAGE = {
  id: 0,
  userId: 0,
  message: "Hi there! I'm your CommUnity Assistant. How can I help you find resources today?",
  isFromUser: false,
  createdAt: new Date(),
};

// Chatbot suggested questions
export const CHATBOT_SUGGESTED_QUESTIONS = [
  "Show me food banks nearby",
  "I need emergency shelter tonight",
  "Where can I find healthcare clinics?",
  "Help me find mental health services",
  "What employment resources are available?",
];
