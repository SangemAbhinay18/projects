import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { Loader2, MapPin, Star, Clock, Phone, Globe, Mail, ArrowLeft, MessageSquare } from "lucide-react";
import { insertReviewSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import Chatbot from "@/components/chatbot/chatbot";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { API_ENDPOINTS } from "@/lib/constants";
import type { ResourceWithDetails } from "@shared/schema";

// Review form schema
const reviewSchema = z.object({
  rating: z.coerce.number().min(1).max(5),
  comment: z.string().min(3, "Comment must be at least 3 characters").max(500, "Comment must be less than 500 characters"),
});

type ReviewFormValues = z.infer<typeof reviewSchema>;

export default function ResourceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isChatbotOpen, setIsChatbotOpen] = useState<boolean>(false);
  const resourceId = parseInt(id);

  // Get resource details
  const { data: resource, isLoading, error } = useQuery<ResourceWithDetails>({
    queryKey: [`${API_ENDPOINTS.RESOURCES}/${resourceId}`],
    enabled: !isNaN(resourceId),
  });

  // Review form
  const form = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      rating: 5,
      comment: "",
    },
  });

  // Submit review mutation
  const submitReviewMutation = useMutation({
    mutationFn: async (values: ReviewFormValues) => {
      const review = {
        resourceId,
        rating: values.rating,
        comment: values.comment,
        userId: user!.id,
      };
      
      const response = await apiRequest(
        "POST", 
        `${API_ENDPOINTS.RESOURCES}/${resourceId}/reviews`, 
        review
      );
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [`${API_ENDPOINTS.RESOURCES}/${resourceId}`] 
      });
      
      toast({
        title: "Review submitted",
        description: "Thank you for sharing your experience!",
      });
      
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error submitting review",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: ReviewFormValues) => {
    submitReviewMutation.mutate(values);
  };

  // Handle navigation back to resources
  const handleBackClick = () => {
    navigate("/");
  };

  // Toggle chatbot
  const toggleChatbot = () => {
    setIsChatbotOpen(!isChatbotOpen);
  };

  // Render stars for rating
  const renderStars = (count: number) => {
    return (
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <span
            key={star}
            className={`cursor-pointer ${
              form.watch("rating") >= star ? "text-yellow-400" : "text-gray-300"
            }`}
            onClick={() => form.setValue("rating", star)}
          >
            <Star className={`h-6 w-6 ${form.watch("rating") >= star ? "fill-yellow-400" : ""}`} />
          </span>
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header showSearch={false} onChatbotToggle={toggleChatbot} />
        <main className="flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </main>
        <Footer />
        <Chatbot isOpen={isChatbotOpen} onClose={() => setIsChatbotOpen(false)} />
      </div>
    );
  }

  if (error || !resource) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header showSearch={false} onChatbotToggle={toggleChatbot} />
        <main className="flex-grow flex items-center justify-center p-4">
          <Card className="w-full max-w-2xl">
            <CardHeader>
              <CardTitle className="text-destructive">Error</CardTitle>
              <CardDescription>
                There was a problem loading this resource.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p>{error?.message || "Resource not found"}</p>
            </CardContent>
            <CardFooter>
              <Button onClick={handleBackClick}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Resources
              </Button>
            </CardFooter>
          </Card>
        </main>
        <Footer />
        <Chatbot isOpen={isChatbotOpen} onClose={() => setIsChatbotOpen(false)} />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header showSearch={false} onChatbotToggle={toggleChatbot} />
      
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <Button
            variant="ghost"
            className="mb-4 flex items-center"
            onClick={handleBackClick}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Resources
          </Button>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Resource details */}
            <div className="md:col-span-2 space-y-6">
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center mb-2">
                    <i className={`ri-${resource.category.icon} text-xl mr-2 text-secondary`}></i>
                    <span className={`bg-${resource.category.color}-100 text-${resource.category.color}-800 text-xs px-2 py-0.5 rounded-full`}>
                      {resource.category.name}
                    </span>
                  </div>
                  <CardTitle className="text-2xl">{resource.name}</CardTitle>
                  <CardDescription className="flex items-center text-sm">
                    <MapPin className="h-4 w-4 mr-1 inline" />
                    {resource.address}, {resource.city}, {resource.state} {resource.zipCode}
                    {resource.distance && (
                      <span className="ml-2 text-primary font-medium">
                        ({resource.distance} miles away)
                      </span>
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="mb-6">{resource.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {resource.openingHours && (
                      <div className="flex items-start">
                        <Clock className="h-5 w-5 mr-2 text-primary" />
                        <div>
                          <h4 className="font-medium text-sm">Opening Hours</h4>
                          <p className="text-sm text-gray-600">{resource.openingHours}</p>
                        </div>
                      </div>
                    )}
                    
                    {resource.phone && (
                      <div className="flex items-start">
                        <Phone className="h-5 w-5 mr-2 text-primary" />
                        <div>
                          <h4 className="font-medium text-sm">Phone</h4>
                          <a href={`tel:${resource.phone}`} className="text-sm text-primary hover:underline">
                            {resource.phone}
                          </a>
                        </div>
                      </div>
                    )}
                    
                    {resource.website && (
                      <div className="flex items-start">
                        <Globe className="h-5 w-5 mr-2 text-primary" />
                        <div>
                          <h4 className="font-medium text-sm">Website</h4>
                          <a href={resource.website} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline">
                            {resource.website}
                          </a>
                        </div>
                      </div>
                    )}
                    
                    {resource.email && (
                      <div className="flex items-start">
                        <Mail className="h-5 w-5 mr-2 text-primary" />
                        <div>
                          <h4 className="font-medium text-sm">Email</h4>
                          <a href={`mailto:${resource.email}`} className="text-sm text-primary hover:underline">
                            {resource.email}
                          </a>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {/* Reviews section */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center">
                    <Star className="h-5 w-5 mr-2 fill-yellow-400 text-yellow-400" />
                    Reviews ({resource.reviews.length})
                    <span className="ml-2 text-sm font-normal text-gray-500">
                      Average: {resource.averageRating.toFixed(1)}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {resource.reviews.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      <MessageSquare className="h-12 w-12 mx-auto mb-2 text-gray-300" />
                      <p>No reviews yet. Be the first to leave a review!</p>
                    </div>
                  ) : (
                    resource.reviews.map((review) => (
                      <div key={review.id} className="pb-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="font-medium">{review.user.username}</div>
                            <div className="flex text-yellow-400">
                              {[...Array(5)].map((_, i) => (
                                <Star 
                                  key={i} 
                                  className={`h-4 w-4 ${i < review.rating ? "fill-yellow-400" : ""}`} 
                                />
                              ))}
                            </div>
                          </div>
                          <div className="text-sm text-gray-500">
                            {new Date(review.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                        <p className="text-gray-700">{review.comment}</p>
                        <Separator className="mt-4" />
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            </div>
            
            {/* Sidebar - submit review */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Leave a Review</CardTitle>
                  <CardDescription>
                    Share your experience to help others in the community
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {user ? (
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="rating"
                          render={() => (
                            <FormItem>
                              <FormLabel>Your Rating</FormLabel>
                              <FormControl>
                                {renderStars(form.watch("rating"))}
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="comment"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Your Review</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Share your experience with this resource..."
                                  className="resize-none"
                                  {...field}
                                />
                              </FormControl>
                              <FormDescription>
                                Your review will help others in need find the right resources.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button
                          type="submit"
                          className="w-full"
                          disabled={submitReviewMutation.isPending}
                        >
                          {submitReviewMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Submitting...
                            </>
                          ) : (
                            "Submit Review"
                          )}
                        </Button>
                      </form>
                    </Form>
                  ) : (
                    <div className="text-center py-4">
                      <p className="mb-4 text-gray-600">
                        You need to be logged in to leave a review.
                      </p>
                      <Button onClick={() => navigate("/auth")}>
                        Log In to Review
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Need Help?</CardTitle>
                  <CardDescription>
                    Our community assistant is here to help you
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full"
                    onClick={toggleChatbot}
                  >
                    <i className="ri-robot-line mr-2"></i>
                    Chat with Assistant
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
      <Chatbot isOpen={isChatbotOpen} onClose={() => setIsChatbotOpen(false)} />
    </div>
  );
}
