import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import MapView from "@/components/map/map-view";
import ResourceList from "@/components/resources/resource-list";
import CategoryFilters from "@/components/resources/category-filters";
import DistanceFilter from "@/components/resources/distance-filter";
import Chatbot from "@/components/chatbot/chatbot";
import { API_ENDPOINTS } from "@/lib/constants";
import mapService from "@/lib/mapbox";
import type { Category, ResourceWithDetails } from "@shared/schema";

export default function HomePage() {
  // State for filters
  const [selectedCategories, setSelectedCategories] = useState<number[]>([]);
  const [distance, setDistance] = useState<number>(10);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isChatbotOpen, setIsChatbotOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedResource, setSelectedResource] = useState<ResourceWithDetails | null>(null);
  
  // Fetch categories
  const { data: categories, isLoading: isCategoriesLoading } = useQuery<Category[]>({
    queryKey: [API_ENDPOINTS.CATEGORIES],
    onSuccess: (data) => {
      // Select all categories by default
      if (data.length > 0 && selectedCategories.length === 0) {
        setSelectedCategories(data.map(category => category.id));
      }
    },
  });
  
  // Attempt to get user location
  useEffect(() => {
    const getUserLocation = async () => {
      try {
        const coords = await mapService.getUserLocation();
        setUserLocation(coords);
      } catch (error) {
        console.error("Error getting user location:", error);
      }
    };
    
    getUserLocation();
  }, []);
  
  // Fetch resources with filters
  const { data: resources, isLoading: isResourcesLoading } = useQuery<ResourceWithDetails[]>({
    queryKey: [
      API_ENDPOINTS.RESOURCES,
      {
        categoryIds: selectedCategories,
        lat: userLocation?.lat,
        lng: userLocation?.lng,
        distance,
        search: searchQuery,
      },
    ],
    enabled: selectedCategories.length > 0,
  });
  
  // Initialize demo data
  const { isLoading: isInitializingDemo } = useQuery({
    queryKey: [API_ENDPOINTS.INIT_DEMO],
    onSuccess: () => {
      console.log("Demo data initialized or already exists");
    },
    onError: (error) => {
      console.error("Failed to initialize demo data:", error);
    },
  });
  
  // Handle resource selection
  const handleResourceSelect = (resource: ResourceWithDetails) => {
    setSelectedResource(resource);
    if (mapService.map) {
      mapService.flyTo({
        lat: resource.latitude,
        lng: resource.longitude,
      });
    }
  };
  
  // Handle category filter change
  const handleCategoryChange = (categoryIds: number[]) => {
    setSelectedCategories(categoryIds);
  };
  
  // Handle distance filter change
  const handleDistanceChange = (value: number) => {
    setDistance(value);
  };
  
  // Handle search
  const handleSearch = (search: string) => {
    setSearchQuery(search);
  };
  
  // Toggle chatbot
  const toggleChatbot = () => {
    setIsChatbotOpen(!isChatbotOpen);
  };
  
  // Loading state
  const isLoading = isCategoriesLoading || isResourcesLoading || isInitializingDemo;
  
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <Header
        onSearchChange={handleSearch}
        onChatbotToggle={toggleChatbot}
      />
      
      {/* Main content */}
      <main className="flex-grow flex flex-col md:flex-row">
        {/* Category and distance filters */}
        <CategoryFilters
          categories={categories || []}
          selectedCategories={selectedCategories}
          onCategoryChange={handleCategoryChange}
          isLoading={isCategoriesLoading}
        />
        
        {/* Main content grid (responsive layout) */}
        <div className="flex-grow flex flex-col md:flex-row">
          {/* Map */}
          <MapView
            resources={resources || []}
            isLoading={isLoading}
            onResourceSelect={handleResourceSelect}
          />
          
          {/* Resource list */}
          <ResourceList
            resources={resources || []}
            isLoading={isLoading}
            selectedResource={selectedResource}
            onResourceSelect={handleResourceSelect}
            filterDistance={distance}
          />
        </div>
        
        {/* Distance filter for mobile */}
        <div className="md:hidden">
          <DistanceFilter
            defaultValue={distance}
            onChange={handleDistanceChange}
          />
        </div>
      </main>
      
      {/* Footer */}
      <Footer />
      
      {/* Chatbot */}
      <Chatbot
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
      />
    </div>
  );
}
