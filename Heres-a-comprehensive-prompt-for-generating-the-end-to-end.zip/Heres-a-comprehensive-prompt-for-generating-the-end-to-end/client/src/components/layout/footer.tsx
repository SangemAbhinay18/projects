import { Link } from "wouter";
import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin 
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between mb-8">
          <div className="mb-6 md:mb-0">
            <div className="flex items-center mb-3">
              <i className="ri-community-line text-2xl mr-2"></i>
              <span className="font-bold text-xl">CommUnity</span>
            </div>
            <p className="text-gray-400 max-w-xs">Connecting people with vital local resources to support communities in need.</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h4 className="font-medium mb-3">Resources</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Food Banks</Link></li>
                <li><Link href="/" className="hover:text-white">Shelters</Link></li>
                <li><Link href="/" className="hover:text-white">Healthcare</Link></li>
                <li><Link href="/" className="hover:text-white">All Categories</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium mb-3">About</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Our Mission</Link></li>
                <li><Link href="/" className="hover:text-white">How It Works</Link></li>
                <li><Link href="/" className="hover:text-white">Partner With Us</Link></li>
                <li><Link href="/" className="hover:text-white">Volunteer</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium mb-3">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/" className="hover:text-white">Help Center</Link></li>
                <li><Link href="/" className="hover:text-white">Contact Us</Link></li>
                <li><Link href="/" className="hover:text-white">Privacy Policy</Link></li>
                <li><Link href="/" className="hover:text-white">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">© {new Date().getFullYear()} CommUnity. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-white">
              <Facebook className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Twitter className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Instagram className="h-5 w-5" />
            </a>
            <a href="#" className="text-gray-400 hover:text-white">
              <Linkedin className="h-5 w-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
