import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, User, Menu, LogOut, HelpCircle } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  onSearchChange?: (search: string) => void;
  onChatbotToggle?: () => void;
  showSearch?: boolean;
}

export default function Header({ onSearchChange, onChatbotToggle, showSearch = true }: HeaderProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [searchValue, setSearchValue] = useState("");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchValue(value);
    if (onSearchChange) {
      onSearchChange(value);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearchChange) {
      onSearchChange(searchValue);
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Logo and mobile menu button */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <i className="ri-community-line text-primary text-2xl mr-2"></i>
              <span className="font-bold text-xl text-primary">CommUnity</span>
            </Link>
            
            <div className="ml-4 md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                <Menu className="h-6 w-6" />
              </Button>
            </div>
          </div>
          
          {/* Desktop search */}
          {showSearch && (
            <div className="hidden md:block">
              <form onSubmit={handleSearchSubmit} className="relative">
                <Input
                  type="text"
                  placeholder="Search resources..."
                  value={searchValue}
                  onChange={handleSearchChange}
                  className="w-64 pl-10 pr-4 py-2 rounded-full"
                />
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </form>
            </div>
          )}
          
          {/* User menu and chatbot toggle */}
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              className="mr-2 text-gray-500 hover:text-primary"
              onClick={onChatbotToggle}
              title="Chatbot Assistant"
            >
              <HelpCircle className="h-5 w-5" />
            </Button>
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span className="hidden md:inline">{user.username}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem disabled>
                    <div className="flex flex-col">
                      <span className="font-medium">{user.username}</span>
                      <span className="text-xs text-muted-foreground">{user.email}</span>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/auth">
                <Button className="bg-primary hover:bg-primary-dark text-white">
                  Log In
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
      
      {/* Mobile search and menu */}
      <div className={`md:hidden ${isMobileMenuOpen ? 'block' : 'hidden'} border-t border-gray-100 p-3`}>
        {showSearch && (
          <form onSubmit={handleSearchSubmit} className="relative mb-3">
            <Input
              type="text"
              placeholder="Search resources..."
              value={searchValue}
              onChange={handleSearchChange}
              className="w-full pl-10 pr-4 py-2 rounded-full"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          </form>
        )}
        
        <div className="space-y-2">
          <Link href="/">
            <Button
              variant={location === "/" ? "default" : "ghost"}
              className="w-full justify-start"
            >
              Home
            </Button>
          </Link>
          {user ? (
            <Button
              variant="outline"
              className="w-full justify-start text-destructive"
              onClick={handleLogout}
            >
              <LogOut className="mr-2 h-4 w-4" />
              <span>Logout</span>
            </Button>
          ) : (
            <Link href="/auth">
              <Button
                variant={location === "/auth" ? "default" : "ghost"}
                className="w-full justify-start"
              >
                Login / Register
              </Button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
