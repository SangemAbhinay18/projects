import { useEffect, useRef, useState } from "react";
import { Loader2, ZoomIn, ZoomOut, MapPin, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import mapService from "@/lib/mapbox";
import type { ResourceWithDetails } from "@shared/schema";

interface MapViewProps {
  resources: ResourceWithDetails[];
  isLoading: boolean;
  onResourceSelect: (resource: ResourceWithDetails) => void;
}

export default function MapView({ resources, isLoading, onResourceSelect }: MapViewProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [mapInitialized, setMapInitialized] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [showLocationAlert, setShowLocationAlert] = useState(true);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  // Initialize map when component mounts
  useEffect(() => {
    if (mapContainerRef.current && !mapInitialized) {
      mapService.init({ container: 'map' });
      setMapInitialized(true);
    }

    return () => {
      // Clean up map markers when component unmounts
      mapService.clearMarkers();
    };
  }, [mapInitialized]);

  // Update markers when resources change
  useEffect(() => {
    if (mapInitialized && resources.length > 0) {
      mapService.createMarkers(resources, onResourceSelect);
      mapService.fitBounds();
    }
  }, [mapInitialized, resources, onResourceSelect]);

  // Get user's location
  const handleGetLocation = async () => {
    setIsLoadingLocation(true);
    setLocationError(null);
    
    try {
      const coords = await mapService.getUserLocation();
      mapService.addUserLocationMarker(coords);
      setShowLocationAlert(false);
    } catch (error) {
      console.error('Error getting location:', error);
      setLocationError('Could not access your location. Please ensure location services are enabled.');
    } finally {
      setIsLoadingLocation(false);
    }
  };

  // Zoom controls
  const handleZoomIn = () => {
    if (mapService.map) {
      mapService.map.zoomIn();
    }
  };

  const handleZoomOut = () => {
    if (mapService.map) {
      mapService.map.zoomOut();
    }
  };

  return (
    <div className="md:w-1/2 lg:w-3/5 bg-gray-100 relative" id="mapContainer">
      <div className="map-container relative" id="map" ref={mapContainerRef}>
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-900/20 z-10">
            <div className="bg-white p-4 rounded-md shadow-md flex items-center">
              <Loader2 className="h-6 w-6 animate-spin text-primary mr-2" />
              <span>Loading resources...</span>
            </div>
          </div>
        )}
        
        {/* Map Controls Overlay */}
        <div className="absolute top-4 right-4 bg-white rounded-md shadow-md p-2 flex space-x-2 z-10">
          <Button
            variant="ghost"
            size="icon"
            className="p-1 hover:bg-gray-100 rounded"
            title="Zoom In"
            onClick={handleZoomIn}
          >
            <ZoomIn className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="p-1 hover:bg-gray-100 rounded"
            title="Zoom Out"
            onClick={handleZoomOut}
          >
            <ZoomOut className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className={`p-1 hover:bg-gray-100 rounded ${isLoadingLocation ? 'opacity-50' : ''}`}
            title="My Location"
            onClick={handleGetLocation}
            disabled={isLoadingLocation}
          >
            {isLoadingLocation ? (
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
            ) : (
              <MapPin className="h-5 w-5 text-primary" />
            )}
          </Button>
        </div>
        
        {/* Location Permission Alert */}
        {showLocationAlert && (
          <div className="absolute top-4 left-1/2 transform -translate-x-1/2 max-w-sm z-10">
            <Alert>
              <AlertTriangle className="h-4 w-4 text-primary mr-2" />
              <AlertTitle>Location Access</AlertTitle>
              <AlertDescription className="flex justify-between items-center">
                <span className="text-sm">Allow location access for nearby resources</span>
                <Button
                  size="sm"
                  className="ml-2 bg-primary text-white"
                  onClick={handleGetLocation}
                  disabled={isLoadingLocation}
                >
                  {isLoadingLocation ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-1" />
                  ) : 'Allow'}
                </Button>
              </AlertDescription>
            </Alert>
          </div>
        )}
        
        {/* Location Error Message */}
        {locationError && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 max-w-sm z-10">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{locationError}</AlertDescription>
            </Alert>
          </div>
        )}
      </div>
    </div>
  );
}
