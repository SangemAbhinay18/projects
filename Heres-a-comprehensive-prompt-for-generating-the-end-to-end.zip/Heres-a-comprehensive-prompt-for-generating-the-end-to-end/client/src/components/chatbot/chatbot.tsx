import { useState, useEffect, useRef } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { X, Send, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { API_ENDPOINTS } from "@/lib/constants";
import { INITIAL_CHATBOT_MESSAGE, CHATBOT_SUGGESTED_QUESTIONS } from "@/lib/constants";
import type { ChatMessage } from "@shared/schema";

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Chatbot({ isOpen, onClose }: ChatbotProps) {
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Fetch chat history if user is logged in
  const { data: chatHistory, isLoading: isLoadingHistory } = useQuery<ChatMessage[]>({
    queryKey: [API_ENDPOINTS.CHAT],
    queryFn: async ({ queryKey }) => {
      if (!user) return [INITIAL_CHATBOT_MESSAGE];
      
      const res = await fetch(queryKey[0] as string, { credentials: "include" });
      if (res.status === 401) return [INITIAL_CHATBOT_MESSAGE];
      
      if (!res.ok) {
        throw new Error("Failed to fetch chat history");
      }
      
      const data = await res.json();
      return data.length ? data : [INITIAL_CHATBOT_MESSAGE];
    },
    enabled: isOpen,
  });

  // Send message mutation
  const { mutate: sendMessage, isPending: isSending } = useMutation({
    mutationFn: async (messageText: string) => {
      if (!user) throw new Error("You must be logged in to use the chatbot");
      
      const res = await apiRequest("POST", API_ENDPOINTS.CHAT, { message: messageText });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [API_ENDPOINTS.CHAT] });
      setMessage("");
      
      // Focus the input after sending
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    },
  });

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !isSending) {
      sendMessage(message);
    }
  };

  // Handle suggested question click
  const handleSuggestedQuestion = (question: string) => {
    if (!isSending) {
      sendMessage(question);
    }
  };

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isOpen]);

  // Focus input when chatbot opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 300);
    }
  }, [isOpen]);

  // Transform chat history for display
  const displayMessages = chatHistory || [INITIAL_CHATBOT_MESSAGE];
  
  // CSS classes for different message types
  const userMessageClasses = "flex justify-end mb-3";
  const userBubbleClasses = "bg-primary text-white rounded-lg p-2 max-w-xs";
  
  const botMessageClasses = "flex mb-3";
  const botBubbleClasses = "bg-gray-200 rounded-lg p-2 max-w-xs";
  
  const suggestedActionClasses = "bg-white text-primary border border-primary rounded-lg p-2 text-sm text-left hover:bg-gray-50";

  return (
    <div 
      className={`fixed bottom-0 right-0 w-80 bg-white shadow-lg rounded-t-lg z-20 transition-transform duration-300 transform ${
        isOpen ? 'translate-y-0' : 'translate-y-full'
      }`}
    >
      {/* Chatbot Header */}
      <div className="bg-primary text-white p-3 rounded-t-lg flex justify-between items-center cursor-pointer">
        <div className="flex items-center">
          <i className="ri-robot-line text-xl mr-2"></i>
          <h3 className="font-medium">CommUnity Assistant</h3>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:text-gray-200 focus:outline-none"
          onClick={onClose}
        >
          <X className="h-5 w-5" />
        </Button>
      </div>
      
      {/* Chat Messages */}
      <div className="h-80 overflow-y-auto p-3 bg-gray-50 custom-scrollbar">
        {isLoadingHistory ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {displayMessages.map((msg, index) => (
              <div key={index} className={msg.isFromUser ? userMessageClasses : botMessageClasses}>
                <div className={msg.isFromUser ? userBubbleClasses : botBubbleClasses}>
                  <p className="text-sm">{msg.message}</p>
                </div>
              </div>
            ))}
            
            {/* Only show suggested questions if we only have the initial message */}
            {displayMessages.length <= 1 && (
              <div className="flex mb-3">
                <div className="flex flex-col space-y-2 max-w-xs w-full">
                  {CHATBOT_SUGGESTED_QUESTIONS.map((question, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className={suggestedActionClasses}
                      onClick={() => handleSuggestedQuestion(question)}
                      disabled={isSending}
                    >
                      {question}
                    </Button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Invisible element to scroll to */}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>
      
      {/* Chat Input */}
      <div className="p-3 border-t border-gray-200">
        <form onSubmit={handleSubmit} className="flex items-center">
          <Input
            ref={inputRef}
            type="text"
            placeholder="Type your question..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-grow px-3 py-2 rounded-l-md"
            disabled={isSending || !user}
          />
          <Button
            type="submit"
            className="bg-primary text-white px-3 py-2 rounded-r-md hover:bg-primary-dark"
            disabled={isSending || !message.trim() || !user}
          >
            {isSending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>
        {!user && (
          <p className="text-xs text-gray-500 mt-2 text-center">
            Please log in to use the chatbot.
          </p>
        )}
      </div>
    </div>
  );
}
