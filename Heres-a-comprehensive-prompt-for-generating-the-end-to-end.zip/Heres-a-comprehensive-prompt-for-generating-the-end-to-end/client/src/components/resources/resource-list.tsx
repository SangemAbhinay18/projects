import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import ResourceCard from "./resource-card";
import type { ResourceWithDetails } from "@shared/schema";

interface ResourceListProps {
  resources: ResourceWithDetails[];
  isLoading: boolean;
  selectedResource: ResourceWithDetails | null;
  onResourceSelect: (resource: ResourceWithDetails) => void;
  totalCount?: number;
  onLoadMore?: () => void;
  loadingMore?: boolean;
  hasMore?: boolean;
  filterDistance?: number;
}

export default function ResourceList({
  resources,
  isLoading,
  selectedResource,
  onResourceSelect,
  totalCount,
  onLoadMore,
  loadingMore = false,
  hasMore = false,
  filterDistance,
}: ResourceListProps) {
  const [animateCards, setAnimateCards] = useState<boolean[]>([]);
  
  // Set up animation for staggered card entry
  useEffect(() => {
    if (resources.length > 0 && !isLoading) {
      const animations = Array(resources.length).fill(false);
      
      // Stagger the animations
      const animationDelays = resources.map((_, index) => {
        return setTimeout(() => {
          setAnimateCards(prev => {
            const updated = [...prev];
            updated[index] = true;
            return updated;
          });
        }, index * 100); // 100ms delay between each card
      });
      
      return () => {
        // Clean up timeouts
        animationDelays.forEach(timeout => clearTimeout(timeout));
      };
    }
  }, [resources, isLoading]);
  
  if (isLoading) {
    return (
      <div className="md:w-1/2 lg:w-2/5 bg-white flex items-center justify-center h-[calc(60vh)] md:h-auto">
        <div className="flex flex-col items-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
          <p className="text-gray-500">Loading resources...</p>
        </div>
      </div>
    );
  }

  if (resources.length === 0) {
    return (
      <div className="md:w-1/2 lg:w-2/5 bg-white flex items-center justify-center h-[calc(60vh)] md:h-auto">
        <div className="flex flex-col items-center p-8">
          <div className="bg-gray-100 p-4 rounded-full mb-4">
            <i className="ri-error-warning-line text-3xl text-gray-400"></i>
          </div>
          <h3 className="text-lg font-medium text-gray-800 mb-2">No Resources Found</h3>
          <p className="text-gray-500 text-center mb-4">
            We couldn't find any resources matching your criteria. Try adjusting your filters or search terms.
          </p>
          <Button
            variant="outline"
            onClick={() => window.location.reload()}
          >
            Reset Filters
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="md:w-1/2 lg:w-2/5 bg-white overflow-y-auto h-[calc(60vh)] md:h-auto custom-scrollbar" id="resourceList">
      <div className="p-4 border-b border-gray-200">
        <h2 className="font-bold text-xl">Resources Near You</h2>
        <p className="text-gray-500 text-sm">
          Showing {resources.length} {totalCount ? `of ${totalCount}` : ''} results
          {filterDistance ? ` within ${filterDistance} miles` : ''}
        </p>
      </div>
      
      {/* Resource Cards */}
      <div>
        {resources.map((resource, index) => (
          <ResourceCard
            key={resource.id}
            resource={resource}
            isSelected={selectedResource?.id === resource.id}
            onClick={() => onResourceSelect(resource)}
            animate={animateCards[index]}
          />
        ))}
      </div>
      
      {/* Load more button */}
      {hasMore && onLoadMore && (
        <div className="p-4 text-center">
          <Button
            variant="outline"
            className="bg-white border border-gray-300 text-gray-700 font-medium py-2 px-4 rounded-md hover:bg-gray-50 transition duration-200"
            onClick={onLoadMore}
            disabled={loadingMore}
          >
            {loadingMore ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Loading...
              </>
            ) : (
              'Load More Resources'
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
