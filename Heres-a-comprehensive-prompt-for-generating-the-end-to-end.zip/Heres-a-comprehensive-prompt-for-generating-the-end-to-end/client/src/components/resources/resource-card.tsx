import type { ResourceWithDetails } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Star, StarHalf } from "lucide-react";

interface ResourceCardProps {
  resource: ResourceWithDetails;
  isSelected?: boolean;
  onClick: () => void;
  animate?: boolean;
}

export default function ResourceCard({
  resource,
  isSelected = false,
  onClick,
  animate = false,
}: ResourceCardProps) {
  // Render stars based on average rating
  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    
    return (
      <div className="flex">
        {[...Array(fullStars)].map((_, i) => (
          <Star key={`full-${i}`} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
        ))}
        {hasHalfStar && (
          <StarHalf className="h-4 w-4 fill-yellow-400 text-yellow-400" />
        )}
        {[...Array(emptyStars)].map((_, i) => (
          <Star key={`empty-${i}`} className="h-4 w-4 text-yellow-400" />
        ))}
      </div>
    );
  };

  // Get icon for resource category
  const getCategoryIcon = (iconName: string) => {
    return `ri-${iconName} text-lg mr-2 text-secondary`;
  };

  // Get color for category badge
  const getCategoryBadgeColor = (color: string) => {
    const colorMap: Record<string, string> = {
      'green': 'bg-green-100 text-green-800',
      'blue': 'bg-blue-100 text-blue-800',
      'purple': 'bg-purple-100 text-purple-800',
      'gray': 'bg-gray-100 text-gray-800',
      'cyan': 'bg-cyan-100 text-cyan-800',
      'red': 'bg-red-100 text-red-800',
    };
    
    return colorMap[color] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div 
      className={cn(
        "border-b border-gray-200 p-4 hover:bg-gray-50 transition cursor-pointer",
        isSelected ? "bg-gray-50" : "",
        animate ? "animate-in fade-in-0 slide-in-from-bottom-4 duration-500" : "opacity-0"
      )}
      onClick={onClick}
    >
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center mb-1">
            <i className={getCategoryIcon(resource.category.icon)}></i>
            <span className={cn("text-xs px-2 py-0.5 rounded-full", getCategoryBadgeColor(resource.category.color))}>
              {resource.category.name}
            </span>
          </div>
          <h3 className="font-medium text-lg">{resource.name}</h3>
          <p className="text-gray-600 text-sm mb-2">{resource.address}, {resource.city}, {resource.state}</p>
          <div className="flex items-center text-sm text-gray-500">
            <i className="ri-map-pin-line mr-1"></i>
            <span>{resource.distance ? `${resource.distance} miles away` : 'Distance unknown'}</span>
            {resource.openingHours && (
              <>
                <span className="mx-2">•</span>
                <i className="ri-time-line mr-1"></i>
                <span>{resource.openingHours}</span>
              </>
            )}
          </div>
        </div>
        <div className="flex flex-col items-end">
          <div className="flex items-center mb-1">
            {renderStars(resource.averageRating)}
            <span className="ml-1 text-sm text-gray-600">{resource.averageRating.toFixed(1)}</span>
          </div>
          <span className="text-xs text-gray-500">{resource.reviews.length} reviews</span>
        </div>
      </div>
    </div>
  );
}
