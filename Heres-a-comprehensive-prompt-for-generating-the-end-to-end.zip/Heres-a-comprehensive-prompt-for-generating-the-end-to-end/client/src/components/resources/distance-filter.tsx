import { useState, useEffect } from "react";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";

interface DistanceFilterProps {
  defaultValue?: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (value: number) => void;
}

export default function DistanceFilter({
  defaultValue = 10,
  min = 1,
  max = 50,
  step = 1,
  onChange,
}: DistanceFilterProps) {
  const [value, setValue] = useState(defaultValue);
  const [isMobile, setIsMobile] = useState(false);
  
  // Update value when defaultValue changes
  useEffect(() => {
    setValue(defaultValue);
  }, [defaultValue]);
  
  // Check if the screen is mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    return () => {
      window.removeEventListener('resize', checkIfMobile);
    };
  }, []);
  
  // Handle slider change
  const handleChange = (newValue: number[]) => {
    setValue(newValue[0]);
    onChange(newValue[0]);
  };
  
  // Toggle the distance filter on mobile
  const [isExpanded, setIsExpanded] = useState(false);
  
  return (
    <div className="border-t border-gray-200 p-4">
      <div 
        className={`flex justify-between items-center mb-3 ${isMobile ? 'cursor-pointer' : ''}`}
        onClick={() => isMobile && setIsExpanded(!isExpanded)}
      >
        <h3 className="font-medium text-lg">Distance</h3>
        {isMobile && (
          <i className={`ri-arrow-${isExpanded ? 'up' : 'down'}-s-line`}></i>
        )}
      </div>
      
      <div className={isMobile && !isExpanded ? 'hidden' : 'block'}>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Label htmlFor="distance-slider" className="text-sm text-gray-500">
              Maximum distance
            </Label>
            <span id="distanceValue" className="text-sm font-medium">
              {value} {value === 1 ? 'mile' : 'miles'}
            </span>
          </div>
          
          <Slider
            id="distance-slider"
            min={min}
            max={max}
            step={step}
            value={[value]}
            onValueChange={handleChange}
            className="w-full h-2"
          />
          
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>{min} mile</span>
            <span>{max} miles</span>
          </div>
        </div>
      </div>
    </div>
  );
}
