import { useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronUp } from "lucide-react";
import type { Category } from "@shared/schema";

interface CategoryFiltersProps {
  categories: Category[];
  selectedCategories: number[];
  onCategoryChange: (categoryIds: number[]) => void;
  isLoading?: boolean;
}

export default function CategoryFilters({
  categories,
  selectedCategories,
  onCategoryChange,
  isLoading = false,
}: CategoryFiltersProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Check if the screen is mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    return () => {
      window.removeEventListener('resize', checkIfMobile);
    };
  }, []);

  // Handle category selection change
  const handleCategoryChange = (categoryId: number, isChecked: boolean) => {
    if (isChecked) {
      onCategoryChange([...selectedCategories, categoryId]);
    } else {
      onCategoryChange(selectedCategories.filter(id => id !== categoryId));
    }
  };

  // Toggle all categories
  const toggleAllCategories = () => {
    if (selectedCategories.length === categories.length) {
      // Deselect all
      onCategoryChange([]);
    } else {
      // Select all
      onCategoryChange(categories.map(category => category.id));
    }
  };

  // Apply filters (mobile only)
  const applyFilters = () => {
    setIsExpanded(false);
  };

  if (isLoading) {
    return (
      <div className="bg-white border-b md:border-b-0 md:border-r border-gray-200 md:w-64 md:flex-shrink-0 p-4">
        <Skeleton className="h-6 w-40 mb-4" />
        <div className="space-y-4">
          {Array(6).fill(0).map((_, i) => (
            <div key={i} className="flex items-center space-x-2">
              <Skeleton className="h-5 w-5 rounded" />
              <Skeleton className="h-4 w-32" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border-b md:border-b-0 md:border-r border-gray-200 md:w-64 md:flex-shrink-0">
      <div className={`p-4 ${isMobile && !isExpanded ? 'cursor-pointer' : ''}`} onClick={() => isMobile && setIsExpanded(!isExpanded)}>
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-medium text-lg">Resource Categories</h3>
          {isMobile && (
            <Button variant="ghost" size="sm" className="p-0 h-auto">
              {isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
            </Button>
          )}
        </div>
        
        <div className={`space-y-3 ${isMobile && !isExpanded ? 'hidden' : ''}`}>
          <div className="flex items-center justify-between mb-2">
            <Button
              variant="link"
              size="sm"
              className="p-0 h-auto text-primary"
              onClick={toggleAllCategories}
            >
              {selectedCategories.length === categories.length ? 'Deselect All' : 'Select All'}
            </Button>
            <span className="text-xs text-gray-500">
              {selectedCategories.length} / {categories.length}
            </span>
          </div>
          
          {categories.map(category => (
            <label key={category.id} className="flex items-center cursor-pointer">
              <Checkbox
                className="h-5 w-5 text-primary rounded"
                checked={selectedCategories.includes(category.id)}
                onCheckedChange={(checked) => 
                  handleCategoryChange(category.id, checked as boolean)
                }
              />
              <span className="ml-2 flex items-center">
                <i className={`ri-${category.icon} text-lg mr-2 text-secondary`}></i>
                {category.name}
              </span>
            </label>
          ))}
        </div>
      </div>
      
      {isMobile && isExpanded && (
        <div className="p-4 border-t border-gray-200">
          <Button className="w-full" onClick={applyFilters}>
            Apply Filters
          </Button>
        </div>
      )}
    </div>
  );
}
