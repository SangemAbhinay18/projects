# Setting up the Community Resource Finder locally

## Prerequisites
- Node.js (v16 or later)
- npm (v7 or later)
- Git

## Step 1: Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/community-resource-finder.git
cd community-resource-finder
```

## Step 2: Install dependencies
```bash
npm install
```

## Step 3: Set environment variables
Create a `.env` file in the root directory with:
```
VITE_MAPBOX_ACCESS_TOKEN=your_mapbox_token_here
MONGODB_URI=your_mongodb_uri_here (optional)
SESSION_SECRET=your_secret_here
```

## Step 4: Start the development server
```bash
npm run dev
```

The application will be available at http://localhost:5000.

## Project Structure
- `client/`: React frontend code
- `server/`: Express backend code
- `shared/`: Shared types and schemas
- `components.json`: shadcn/ui configuration
- `drizzle.config.ts`: Drizzle ORM configuration
- `render.yaml`: Render deployment configuration
- `Procfile`: Procfile for deployment

## Core Files to Understand
- `server/routes.ts`: API route configuration
- `server/storage.ts`: Data storage implementation
- `server/auth.ts`: Authentication logic
- `client/src/App.tsx`: Main application component
- `client/src/hooks/use-auth.tsx`: Authentication hook
- `shared/schema.ts`: Database schema definitions