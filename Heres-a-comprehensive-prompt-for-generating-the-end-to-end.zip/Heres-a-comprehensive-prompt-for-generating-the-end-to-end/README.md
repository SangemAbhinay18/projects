# Community Resource Finder

A web application for finding community resources such as food banks, shelters, and clinics based on location.

## Features

- User authentication (signup/login)
- Resource search by category and location
- Map integration with Mapbox
- Resource details with ratings and reviews
- Chatbot assistance
- Mobile responsive design

## Tech Stack

- Frontend: React, TailwindCSS, shadcn/ui
- Backend: Express, Node.js
- Map: Mapbox GL JS
- Database: MongoDB (with fallback to in-memory storage)
- Authentication: Passport.js

## Deployment to Render

1. Fork/Clone this repository
2. Connect your GitHub repository to Render
3. Create a new Web Service
4. Use the following settings:
   - Build Command: `npm install && npm run build`
   - Start Command: `npm start`
5. Add the following environment variables:
   - `NODE_ENV`: `production`
   - `VITE_MAPBOX_ACCESS_TOKEN`: Your Mapbox access token
   - `MONGODB_URI`: Your MongoDB connection string
   - `SESSION_SECRET`: A secure random string

## Local Development

1. Clone the repository
2. Install dependencies: `npm install`
3. Start the development server: `npm run dev`
4. Open http://localhost:5000 in your browser

## Environment Variables

- `VITE_MAPBOX_ACCESS_TOKEN`: Required for map functionality
- `MONGODB_URI`: MongoDB connection string (optional, falls back to in-memory storage)
- `SESSION_SECRET`: Secret for session encryption (automatically generated in development)

## License

MIT