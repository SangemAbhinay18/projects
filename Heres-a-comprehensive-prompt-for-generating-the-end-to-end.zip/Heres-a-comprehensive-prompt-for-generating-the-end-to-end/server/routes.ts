import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { setupResourceRoutes } from "./resources";
import { setupChatbotRoutes } from "./chatbot";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for Render
  app.get("/api/health", (_req, res) => {
    res.status(200).json({ status: "ok" });
  });

  // Set up authentication routes (/api/register, /api/login, /api/logout, /api/user)
  setupAuth(app);
  
  // Set up resource-related routes
  setupResourceRoutes(app);
  
  // Set up chatbot routes
  setupChatbotRoutes(app);
  
  // Sample data endpoint to initialize data for demo purposes
  app.get("/api/init-demo-data", async (req, res) => {
    try {
      // Get existing categories
      const categories = await storage.getCategories();
      
      if (categories.length === 0) {
        return res.status(500).json({ message: "Categories not initialized" });
      }
      
      // Create sample resources if none exist
      const resources = await storage.getResources();
      
      if (resources.length === 0) {
        // Sample resources for Boulder, CO area
        const sampleResources = [
          {
            name: "Community Food Share",
            description: "Community Food Share's mission is to eliminate hunger in Boulder and Broomfield Counties through engagement, collaboration, and leadership.",
            address: "650 S Taylor Ave",
            city: "Louisville",
            state: "CO",
            zipCode: "80027",
            phone: "(303) 652-3663",
            website: "https://communityfoodshare.org",
            email: "info@communityfoodshare.org",
            latitude: 39.9774,
            longitude: -105.0857,
            categoryId: categories.find(c => c.name === "Food Banks")?.id || 1,
            openingHours: "Mon-Fri: 8am-5pm, Sat: 9am-1pm"
          },
          {
            name: "Hope Harbor Shelter",
            description: "Emergency shelter providing temporary housing and support services to individuals and families experiencing homelessness.",
            address: "1175 Jay Street",
            city: "Boulder",
            state: "CO",
            zipCode: "80302",
            phone: "(303) 442-4646",
            website: "https://bouldershelter.org",
            email: "info@bouldershelter.org",
            latitude: 40.0274,
            longitude: -105.2519,
            categoryId: categories.find(c => c.name === "Shelters")?.id || 2,
            openingHours: "Open 24/7"
          },
          {
            name: "Peoples Clinic",
            description: "Provides high-quality, affordable healthcare services to underserved communities in Boulder County.",
            address: "2525 13th St",
            city: "Boulder",
            state: "CO",
            zipCode: "80304",
            phone: "(303) 449-6050",
            website: "https://peoplesclinic.org",
            email: "info@peoplesclinic.org",
            latitude: 40.0216,
            longitude: -105.2797,
            categoryId: categories.find(c => c.name === "Healthcare Clinics")?.id || 3,
            openingHours: "Mon-Fri: 8am-5pm"
          },
          {
            name: "Mental Health Partners",
            description: "Provides mental health and substance use services for all ages, income levels, and insurance types.",
            address: "1333 Iris Ave",
            city: "Boulder",
            state: "CO",
            zipCode: "80304",
            phone: "(303) 443-8500",
            website: "https://mhpcolorado.org",
            email: "info@mhpcolorado.org",
            latitude: 40.0343,
            longitude: -105.2854,
            categoryId: categories.find(c => c.name === "Mental Health Services")?.id || 6,
            openingHours: "Mon-Fri: 8am-6pm"
          }
        ];
        
        // Create each sample resource
        for (const resource of sampleResources) {
          await storage.createResource(resource);
        }
        
        return res.status(200).json({ message: "Demo data initialized successfully" });
      } else {
        return res.status(200).json({ message: "Demo data already exists" });
      }
    } catch (error) {
      console.error("Error initializing demo data:", error);
      res.status(500).json({ message: "Failed to initialize demo data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
