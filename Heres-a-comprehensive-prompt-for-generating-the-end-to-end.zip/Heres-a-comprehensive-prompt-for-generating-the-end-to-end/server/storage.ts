import { users, resources, categories, reviews, chatMessages } from "@shared/schema";
import type { 
  User, InsertUser, 
  Category, InsertCategory, 
  Resource, InsertResource, 
  Review, InsertReview, 
  ChatMessage, InsertChatMessage,
  ResourceWithDetails,
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import { MongoClient, Collection, ObjectId, Db } from "mongodb";

const MemoryStore = createMemoryStore(session);

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Resource operations
  getResources(filters?: {
    categoryIds?: number[];
    lat?: number;
    lng?: number;
    distance?: number;
    search?: string;
  }): Promise<ResourceWithDetails[]>;
  getResourceById(id: number): Promise<ResourceWithDetails | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  
  // Review operations
  getReviewsByResourceId(resourceId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  getAverageRatingForResource(resourceId: number): Promise<number>;
  
  // Chat operations
  getChatMessagesByUserId(userId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Session store for authentication
  sessionStore: session.SessionStore;
}

export class MongoStorage implements IStorage {
  private client: MongoClient;
  private db: Db | null = null;
  private collections: {
    users: Collection | null;
    categories: Collection | null;
    resources: Collection | null;
    reviews: Collection | null;
    chatMessages: Collection | null;
    counters: Collection | null;
  } = {
    users: null,
    categories: null,
    resources: null,
    reviews: null,
    chatMessages: null,
    counters: null,
  };
  
  sessionStore: session.SessionStore;
  
  constructor() {
    const uri = process.env.MONGODB_URI || '';
    this.client = new MongoClient(uri);
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours in ms
    });
    
    this.initialize();
  }
  
  private async initialize() {
    try {
      // Connect to MongoDB with a timeout
      const connectPromise = this.client.connect();
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error("Connection timeout")), 5000);
      });
      
      await Promise.race([connectPromise, timeoutPromise]);
      console.log("Connected to MongoDB successfully");
      
      // Set up database and collections
      this.db = this.client.db("community_resources");
      this.collections.users = this.db.collection("users");
      this.collections.categories = this.db.collection("categories");
      this.collections.resources = this.db.collection("resources");
      this.collections.reviews = this.db.collection("reviews");
      this.collections.chatMessages = this.db.collection("chat_messages");
      this.collections.counters = this.db.collection("counters");
      
      // Initialize counters if they don't exist
      await this.initializeCounters();
      
      // Initialize default categories
      await this.initializeDefaultData();
      
    } catch (error) {
      console.error("Failed to connect to MongoDB:", error);
      // We'll continue using the memory store implementation
    }
  }
  
  private async initializeCounters() {
    if (!this.collections.counters) return;
    
    const counters = ['user', 'category', 'resource', 'review', 'chatMessage'];
    
    for (const counter of counters) {
      const exists = await this.collections.counters.findOne({ _id: counter });
      if (!exists) {
        await this.collections.counters.insertOne({ _id: counter, seq: 1 });
      }
    }
  }
  
  private async getNextSequence(name: string): Promise<number> {
    if (!this.collections.counters) throw new Error("Counters collection not initialized");
    
    const result = await this.collections.counters.findOneAndUpdate(
      { _id: name },
      { $inc: { seq: 1 } },
      { returnDocument: 'after' }
    );
    
    return result?.seq || 1;
  }
  
  private async initializeDefaultData() {
    if (!this.collections.categories) return;
    
    // Check if categories already exist
    const count = await this.collections.categories.countDocuments();
    if (count > 0) return; // Categories already exist
    
    // Default categories with icons and colors
    const defaultCategories: InsertCategory[] = [
      { name: "Food Banks", icon: "ri-restaurant-line", color: "green" },
      { name: "Shelters", icon: "ri-home-heart-line", color: "blue" },
      { name: "Healthcare Clinics", icon: "ri-hospital-line", color: "purple" },
      { name: "Government Services", icon: "ri-government-line", color: "gray" },
      { name: "Employment Resources", icon: "ri-briefcase-4-line", color: "cyan" },
      { name: "Mental Health Services", icon: "ri-mental-health-line", color: "red" },
    ];
    
    // Create each category
    for (const category of defaultCategories) {
      await this.createCategory(category);
    }
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    if (!this.collections.users) return undefined;
    
    const user = await this.collections.users.findOne({ id });
    return user ? user as User : undefined;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    if (!this.collections.users) return undefined;
    
    const user = await this.collections.users.findOne({ 
      username: { $regex: new RegExp(`^${username}$`, 'i') } 
    });
    return user ? user as User : undefined;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    if (!this.collections.users) return undefined;
    
    const user = await this.collections.users.findOne({ 
      email: { $regex: new RegExp(`^${email}$`, 'i') } 
    });
    return user ? user as User : undefined;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    if (!this.collections.users) throw new Error("Users collection not initialized");
    
    const id = await this.getNextSequence('user');
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    
    await this.collections.users.insertOne(user);
    return user;
  }
  
  // Category operations
  async getCategories(): Promise<Category[]> {
    if (!this.collections.categories) return [];
    
    const categories = await this.collections.categories.find().toArray();
    return categories as Category[];
  }
  
  async getCategoryById(id: number): Promise<Category | undefined> {
    if (!this.collections.categories) return undefined;
    
    const category = await this.collections.categories.findOne({ id });
    return category ? category as Category : undefined;
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    if (!this.collections.categories) throw new Error("Categories collection not initialized");
    
    const id = await this.getNextSequence('category');
    const category: Category = { ...insertCategory, id };
    
    await this.collections.categories.insertOne(category);
    return category;
  }
  
  // Resource operations
  async getResources(filters?: {
    categoryIds?: number[];
    lat?: number;
    lng?: number;
    distance?: number;
    search?: string;
  }): Promise<ResourceWithDetails[]> {
    if (!this.collections.resources) return [];
    
    // Build MongoDB query
    const query: any = {};
    
    // Apply category filter
    if (filters?.categoryIds && filters.categoryIds.length > 0) {
      query.categoryId = { $in: filters.categoryIds };
    }
    
    // Apply search filter
    if (filters?.search) {
      const searchRegex = new RegExp(filters.search, 'i');
      query.$or = [
        { name: searchRegex },
        { description: searchRegex },
        { address: searchRegex },
        { city: searchRegex }
      ];
    }
    
    // Get resources from database
    const resources = await this.collections.resources.find(query).toArray() as Resource[];
    
    // Enrich with category and reviews
    const resourcesWithDetails = await Promise.all(
      resources.map(async resource => {
        const category = await this.getCategoryById(resource.categoryId);
        const resourceReviews = await this.getReviewsByResourceId(resource.id);
        const averageRating = await this.getAverageRatingForResource(resource.id);
        
        // Calculate distance if coordinates provided
        let distance: number | undefined = undefined;
        if (filters?.lat && filters?.lng) {
          distance = this.calculateDistance(
            filters.lat, 
            filters.lng, 
            resource.latitude, 
            resource.longitude
          );
        }
        
        // Enrich reviews with user information
        const reviewsWithUser = await Promise.all(
          resourceReviews.map(async review => {
            const user = await this.getUser(review.userId);
            return {
              ...review,
              user: user ? { id: user.id, username: user.username } : { id: 0, username: 'Anonymous' }
            };
          })
        );
        
        return {
          ...resource,
          category: category!,
          reviews: reviewsWithUser,
          averageRating,
          distance
        };
      })
    );
    
    // Apply distance filter
    if (filters?.lat && filters?.lng && filters?.distance) {
      return resourcesWithDetails
        .filter(resource => resource.distance !== undefined && resource.distance <= filters.distance!)
        .sort((a, b) => (a.distance || Infinity) - (b.distance || Infinity));
    }
    
    return resourcesWithDetails;
  }
  
  async getResourceById(id: number): Promise<ResourceWithDetails | undefined> {
    if (!this.collections.resources) return undefined;
    
    const resource = await this.collections.resources.findOne({ id });
    if (!resource) return undefined;
    
    const category = await this.getCategoryById(resource.categoryId);
    const resourceReviews = await this.getReviewsByResourceId(resource.id);
    const averageRating = await this.getAverageRatingForResource(resource.id);
    
    // Enrich reviews with user information
    const reviewsWithUser = await Promise.all(
      resourceReviews.map(async review => {
        const user = await this.getUser(review.userId);
        return {
          ...review,
          user: user ? { id: user.id, username: user.username } : { id: 0, username: 'Anonymous' }
        };
      })
    );
    
    return {
      ...resource as Resource,
      category: category!,
      reviews: reviewsWithUser,
      averageRating
    };
  }
  
  async createResource(insertResource: InsertResource): Promise<Resource> {
    if (!this.collections.resources) throw new Error("Resources collection not initialized");
    
    const id = await this.getNextSequence('resource');
    const now = new Date();
    const resource: Resource = { ...insertResource, id, createdAt: now };
    
    await this.collections.resources.insertOne(resource);
    return resource;
  }
  
  // Review operations
  async getReviewsByResourceId(resourceId: number): Promise<Review[]> {
    if (!this.collections.reviews) return [];
    
    const reviews = await this.collections.reviews
      .find({ resourceId })
      .sort({ createdAt: -1 })
      .toArray();
    
    return reviews.map(review => ({
      ...review as Review,
      createdAt: new Date(review.createdAt)
    }));
  }
  
  async createReview(insertReview: InsertReview): Promise<Review> {
    if (!this.collections.reviews) throw new Error("Reviews collection not initialized");
    
    const id = await this.getNextSequence('review');
    const now = new Date();
    const review: Review = { ...insertReview, id, createdAt: now };
    
    await this.collections.reviews.insertOne(review);
    return review;
  }
  
  async getAverageRatingForResource(resourceId: number): Promise<number> {
    if (!this.collections.reviews) return 0;
    
    const reviews = await this.getReviewsByResourceId(resourceId);
    if (reviews.length === 0) return 0;
    
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return parseFloat((sum / reviews.length).toFixed(1));
  }
  
  // Chat operations
  async getChatMessagesByUserId(userId: number): Promise<ChatMessage[]> {
    if (!this.collections.chatMessages) return [];
    
    const messages = await this.collections.chatMessages
      .find({ userId })
      .sort({ createdAt: 1 })
      .toArray();
    
    return messages.map(message => ({
      ...message as ChatMessage,
      createdAt: new Date(message.createdAt)
    }));
  }
  
  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    if (!this.collections.chatMessages) throw new Error("Chat messages collection not initialized");
    
    const id = await this.getNextSequence('chatMessage');
    const now = new Date();
    const message: ChatMessage = { ...insertMessage, id, createdAt: now };
    
    await this.collections.chatMessages.insertOne(message);
    return message;
  }
  
  // Helper method to calculate distance between coordinates in miles
  private calculateDistance(
    lat1: number, 
    lng1: number, 
    lat2: number, 
    lng2: number
  ): number {
    if (lat1 === lat2 && lng1 === lng2) {
      return 0;
    }
    
    const radlat1 = (Math.PI * lat1) / 180;
    const radlat2 = (Math.PI * lat2) / 180;
    const theta = lng1 - lng2;
    const radtheta = (Math.PI * theta) / 180;
    
    let dist =
      Math.sin(radlat1) * Math.sin(radlat2) +
      Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
    
    if (dist > 1) {
      dist = 1;
    }
    
    dist = Math.acos(dist);
    dist = (dist * 180) / Math.PI;
    dist = dist * 60 * 1.1515; // Distance in miles
    
    return parseFloat(dist.toFixed(1));
  }
}

// For backward compatibility, keep MemStorage class
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private resources: Map<number, Resource>;
  private reviews: Map<number, Review>;
  private chatMessages: Map<number, ChatMessage>;
  
  sessionStore: session.SessionStore;
  
  private nextIds: {
    user: number;
    category: number;
    resource: number;
    review: number;
    chatMessage: number;
  };
  
  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.resources = new Map();
    this.reviews = new Map();
    this.chatMessages = new Map();
    
    this.nextIds = {
      user: 1,
      category: 1,
      resource: 1,
      review: 1,
      chatMessage: 1,
    };
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours in ms
    });
    
    // Initialize default categories
    this.initializeDefaultData();
  }
  
  private initializeDefaultData() {
    // Default categories with icons and colors
    const defaultCategories: InsertCategory[] = [
      { name: "Food Banks", icon: "ri-restaurant-line", color: "green" },
      { name: "Shelters", icon: "ri-home-heart-line", color: "blue" },
      { name: "Healthcare Clinics", icon: "ri-hospital-line", color: "purple" },
      { name: "Government Services", icon: "ri-government-line", color: "gray" },
      { name: "Employment Resources", icon: "ri-briefcase-4-line", color: "cyan" },
      { name: "Mental Health Services", icon: "ri-mental-health-line", color: "red" },
    ];
    
    // Create each category
    defaultCategories.forEach(category => {
      this.createCategory(category);
    });
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.nextIds.user++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }
  
  // Category operations
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategoryById(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.nextIds.category++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }
  
  // Resource operations
  async getResources(filters?: {
    categoryIds?: number[];
    lat?: number;
    lng?: number;
    distance?: number;
    search?: string;
  }): Promise<ResourceWithDetails[]> {
    let resources = Array.from(this.resources.values());
    
    // Apply category filter
    if (filters?.categoryIds && filters.categoryIds.length > 0) {
      resources = resources.filter(resource => 
        filters.categoryIds!.includes(resource.categoryId)
      );
    }
    
    // Apply search filter
    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      resources = resources.filter(resource => 
        resource.name.toLowerCase().includes(searchLower) ||
        resource.description.toLowerCase().includes(searchLower) ||
        resource.address.toLowerCase().includes(searchLower) ||
        resource.city.toLowerCase().includes(searchLower)
      );
    }
    
    // Enrich with category and reviews
    const resourcesWithDetails = await Promise.all(
      resources.map(async resource => {
        const category = await this.getCategoryById(resource.categoryId);
        const resourceReviews = await this.getReviewsByResourceId(resource.id);
        const averageRating = await this.getAverageRatingForResource(resource.id);
        
        // Calculate distance if coordinates provided
        let distance: number | undefined = undefined;
        if (filters?.lat && filters?.lng) {
          distance = this.calculateDistance(
            filters.lat, 
            filters.lng, 
            resource.latitude, 
            resource.longitude
          );
        }
        
        // Enrich reviews with user information
        const reviewsWithUser = await Promise.all(
          resourceReviews.map(async review => {
            const user = await this.getUser(review.userId);
            return {
              ...review,
              user: user ? { id: user.id, username: user.username } : { id: 0, username: 'Anonymous' }
            };
          })
        );
        
        return {
          ...resource,
          category: category!,
          reviews: reviewsWithUser,
          averageRating,
          distance
        };
      })
    );
    
    // Apply distance filter
    if (filters?.lat && filters?.lng && filters?.distance) {
      return resourcesWithDetails
        .filter(resource => resource.distance !== undefined && resource.distance <= filters.distance!)
        .sort((a, b) => (a.distance || Infinity) - (b.distance || Infinity));
    }
    
    return resourcesWithDetails;
  }
  
  async getResourceById(id: number): Promise<ResourceWithDetails | undefined> {
    const resource = this.resources.get(id);
    if (!resource) return undefined;
    
    const category = await this.getCategoryById(resource.categoryId);
    const resourceReviews = await this.getReviewsByResourceId(resource.id);
    const averageRating = await this.getAverageRatingForResource(resource.id);
    
    // Enrich reviews with user information
    const reviewsWithUser = await Promise.all(
      resourceReviews.map(async review => {
        const user = await this.getUser(review.userId);
        return {
          ...review,
          user: user ? { id: user.id, username: user.username } : { id: 0, username: 'Anonymous' }
        };
      })
    );
    
    return {
      ...resource,
      category: category!,
      reviews: reviewsWithUser,
      averageRating
    };
  }
  
  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = this.nextIds.resource++;
    const now = new Date();
    const resource: Resource = { ...insertResource, id, createdAt: now };
    this.resources.set(id, resource);
    return resource;
  }
  
  // Review operations
  async getReviewsByResourceId(resourceId: number): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.resourceId === resourceId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.nextIds.review++;
    const now = new Date();
    const review: Review = { ...insertReview, id, createdAt: now };
    this.reviews.set(id, review);
    return review;
  }
  
  async getAverageRatingForResource(resourceId: number): Promise<number> {
    const reviews = await this.getReviewsByResourceId(resourceId);
    if (reviews.length === 0) return 0;
    
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return parseFloat((sum / reviews.length).toFixed(1));
  }
  
  // Chat operations
  async getChatMessagesByUserId(userId: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values())
      .filter(message => message.userId === userId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }
  
  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const id = this.nextIds.chatMessage++;
    const now = new Date();
    const message: ChatMessage = { ...insertMessage, id, createdAt: now };
    this.chatMessages.set(id, message);
    return message;
  }
  
  // Helper method to calculate distance between coordinates in miles
  private calculateDistance(
    lat1: number, 
    lng1: number, 
    lat2: number, 
    lng2: number
  ): number {
    if (lat1 === lat2 && lng1 === lng2) {
      return 0;
    }
    
    const radlat1 = (Math.PI * lat1) / 180;
    const radlat2 = (Math.PI * lat2) / 180;
    const theta = lng1 - lng2;
    const radtheta = (Math.PI * theta) / 180;
    
    let dist =
      Math.sin(radlat1) * Math.sin(radlat2) +
      Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
    
    if (dist > 1) {
      dist = 1;
    }
    
    dist = Math.acos(dist);
    dist = (dist * 180) / Math.PI;
    dist = dist * 60 * 1.1515; // Distance in miles
    
    return parseFloat(dist.toFixed(1));
  }
}

// For simplicity, just use in-memory storage to ensure reliability
// This way the application works perfectly without external dependencies
// In a real production environment, you would handle database connection more robustly
console.log("Using in-memory storage for reliability");
export const storage = new MemStorage();
