import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { insertResourceSchema, insertReviewSchema } from "@shared/schema";
import { z } from "zod";

// Resource filters schema
const resourceFiltersSchema = z.object({
  categoryIds: z.array(z.coerce.number()).optional(),
  lat: z.coerce.number().optional(),
  lng: z.coerce.number().optional(),
  distance: z.coerce.number().optional(),
  search: z.string().optional(),
});

export function setupResourceRoutes(app: Express) {
  // Get all categories
  app.get("/api/categories", async (_req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  // Get resources with optional filters
  app.get("/api/resources", async (req, res) => {
    try {
      // Parse and validate query parameters
      const filters = resourceFiltersSchema.parse({
        categoryIds: req.query.categoryIds 
          ? Array.isArray(req.query.categoryIds)
            ? req.query.categoryIds
            : [req.query.categoryIds]
          : undefined,
        lat: req.query.lat,
        lng: req.query.lng,
        distance: req.query.distance,
        search: req.query.search,
      });

      const resources = await storage.getResources(filters);
      res.json(resources);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid query parameters", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to fetch resources" });
    }
  });

  // Get a specific resource by ID
  app.get("/api/resources/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid resource ID" });
      }

      const resource = await storage.getResourceById(id);
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }

      res.json(resource);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resource" });
    }
  });

  // Create a new resource (protected route)
  app.post("/api/resources", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertResourceSchema.parse(req.body);
      const resource = await storage.createResource(validatedData);
      res.status(201).json(resource);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create resource" });
    }
  });

  // Get reviews for a resource
  app.get("/api/resources/:id/reviews", async (req, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      if (isNaN(resourceId)) {
        return res.status(400).json({ message: "Invalid resource ID" });
      }

      const reviews = await storage.getReviewsByResourceId(resourceId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  // Create a review for a resource (protected route)
  app.post("/api/resources/:id/reviews", isAuthenticated, async (req, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      if (isNaN(resourceId)) {
        return res.status(400).json({ message: "Invalid resource ID" });
      }

      const resource = await storage.getResourceById(resourceId);
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }

      const validatedData = insertReviewSchema.parse({
        ...req.body,
        resourceId,
        userId: req.user.id,
      });

      const review = await storage.createReview(validatedData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });
}

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}
