import { Express } from "express";
import { storage } from "./storage";
import { insertChatMessageSchema } from "@shared/schema";
import { z } from "zod";

// Simple patterns for the chatbot to recognize and respond to
const CHATBOT_PATTERNS = [
  {
    pattern: /(food|hungry|eat|meal)/i,
    response: "I can help you find food banks near you. Would you like me to show you nearby food banks?"
  },
  {
    pattern: /(shelter|housing|homeless|sleep|stay)/i,
    response: "If you need shelter, I can locate emergency housing options near you. Shall I find nearby shelters?"
  },
  {
    pattern: /(health|doctor|medical|clinic|sick|illness)/i,
    response: "For health concerns, I can find local clinics that offer free or low-cost services. Would you like to see healthcare options?"
  },
  {
    pattern: /(job|work|employment|career|hire|hiring)/i,
    response: "Looking for employment resources? I can show you job assistance centers in your area. Would that be helpful?"
  },
  {
    pattern: /(mental|therapy|counseling|depression|anxiety)/i,
    response: "Mental health is important. I can help you find mental health services near you. Would you like me to show those?"
  },
  {
    pattern: /(government|benefits|assistance|aid|help)/i,
    response: "For government assistance programs, I can point you to local offices. Would you like to see government service locations?"
  },
  {
    pattern: /(hello|hi|hey|greetings)/i,
    response: "Hello! I'm your CommUnity Assistant. How can I help you find resources today?"
  },
  {
    pattern: /(thank|thanks)/i,
    response: "You're welcome! I'm here to help. Is there anything else you'd like to know about community resources?"
  },
  {
    pattern: /(bye|goodbye|farewell)/i,
    response: "Goodbye! Feel free to come back if you need any more help finding community resources."
  }
];

// Default response when no pattern matches
const DEFAULT_RESPONSE = "I'm here to help you find community resources. You can ask about food banks, shelters, healthcare clinics, employment resources, or mental health services.";

export function setupChatbotRoutes(app: Express) {
  // Get chat history for the authenticated user
  app.get("/api/chat", isAuthenticated, async (req, res) => {
    try {
      const messages = await storage.getChatMessagesByUserId(req.user.id);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat history" });
    }
  });

  // Send a message to the chatbot
  app.post("/api/chat", isAuthenticated, async (req, res) => {
    try {
      // Validate and create user message
      const userMessageData = insertChatMessageSchema.parse({
        userId: req.user.id,
        message: req.body.message,
        isFromUser: true
      });
      
      const userMessage = await storage.createChatMessage(userMessageData);
      
      // Generate chatbot response
      const botResponse = generateChatbotResponse(req.body.message);
      
      // Save chatbot response
      const botMessageData = insertChatMessageSchema.parse({
        userId: req.user.id,
        message: botResponse,
        isFromUser: false
      });
      
      const botMessage = await storage.createChatMessage(botMessageData);
      
      // Return both messages
      res.status(201).json({
        userMessage,
        botMessage
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to process chat message" });
    }
  });
}

// Generate a response based on the user's message
function generateChatbotResponse(userMessage: string): string {
  // Check if the message matches any pattern
  for (const { pattern, response } of CHATBOT_PATTERNS) {
    if (pattern.test(userMessage)) {
      return response;
    }
  }
  
  // Return default response if no pattern matches
  return DEFAULT_RESPONSE;
}

// Middleware to check if user is authenticated
function isAuthenticated(req: any, res: any, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}
